package Day03;




//커피 타입[이름, 카페인양, 가격


public class OOP {
    public static void main(String[] args) {
//        Student umm = new Student();
//
//        umm.name = "엄준식";
//        umm.Grade = 3;
//        umm.gender = "남자";
//
//        System.out.println(umm.name);
//        System.out.println(umm.introduce());
//
//        Coffee cf = new Coffee("아메리카노", 10,4000);
//        System.out.println(cf.coffeeName);
//        System.out.println(cf.price);
//        System.out.println(cf.howMuchCaffein);
//
//        System.out.println(cf.intro());


        Car tico = new Car("티코","대우",1991);

        tico.speedDown();
        tico.speedDown();
        tico.speedDown();
//        tico.speedUp();
//        tico.speedUp();
        for (int i = 0; i < 150; i++) {
            tico.speedUp();
            System.out.println(tico.showSpeed());
        }

        System.out.println(tico.showSpeed());



    }
}
