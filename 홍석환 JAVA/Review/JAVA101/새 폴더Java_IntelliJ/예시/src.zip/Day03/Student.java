package Day03;

public class Student {
    String name;
    int Grade;
    String gender;


//    자바의 함수 정의
//    돌려주는 타입 public 함수이름 (){}
    public  String introduce(){
        return "학생입니다";
    }

    public String living(){
        return "인천에 삽니다";
    }

}
