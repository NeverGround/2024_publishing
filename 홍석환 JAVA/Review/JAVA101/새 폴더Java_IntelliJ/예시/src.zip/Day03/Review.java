package Day03;

import java.util.Scanner;

public class Review {
    public static void main(String[] args) {
//        유저에게 커피 메뉴 3개 물어본 뒤 모두 출력하기
        Scanner sc = new Scanner(System.in);

        String[] menus = new String[3];

        for (int i = 0; i < 3; i++) {
            System.out.println("커피메뉴" + (i+1) + "번을 입력하세요:");
            menus[i] = sc.nextLine();
        }

        for (int i = 0; i < 3; i++) {
            System.out.println(menus[i]);
        }


    }
}
