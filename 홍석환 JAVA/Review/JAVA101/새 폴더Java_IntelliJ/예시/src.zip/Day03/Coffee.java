package Day03;

public class Coffee {
    String coffeeName;
    int howMuchCaffein;
    int price;

    public String orderCoffee (){
        return coffeeName + "주문합니다";
    }

    //함수[초기화 함수(생성자 함수) + 일반함수]
    public Coffee(String n, int c, int p){
        this.coffeeName = n;  //나(Coffee)를 가리킴
        this.price = p;
        this.howMuchCaffein = c;
    }

    //소개해주는 함수
    public String intro(){
        return  "커피이름: " + this.coffeeName + "카페인양: " + this.howMuchCaffein + "가격: " + this.price;
    }

}




