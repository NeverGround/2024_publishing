package Day03;

//변수 -> 구조체 -> 클래스

// OOP('객체 지향 프로그래밍' 의 약자)
// 객체: 세상에 있는 모든것
//1. 캡슐화
//2. 다형성
//3. 상속

// 클래스():
// private & public 캡슐화[데이터보호해줌]: 데이터 아작 안내줌



//private 남한테 이 변수를 노출 안해줌
//public 남한테 이 변수를 보여줌

//getter setter를 주로 씀.

public class Car {
    private String modelName;
    private String company;
    private int madeYear;
    private int velocity;

    //생성해주는 함수
    public Car(String modelName, String company, int madeYear) {
        this.modelName = modelName;
        this.company = company;
        this.madeYear = madeYear;
        this.velocity = 0;
    }

    public String getModelName() {
        return modelName;
    }

    public void setModelName(String modelName) {
        this.modelName = modelName;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public int getMadeYear() {
        return madeYear;
    }

    public void setMadeYear(int madeYear) {
        if (madeYear< 1900){
            System.out.println("데이터 입력 오류");
        }else {
            this.madeYear = madeYear;
        }

    }

    public int getVelocity() {
        return velocity;
    }

    public void setVelocity(int velocity) {
        this.velocity = velocity;
    }

    //    속도 올리는 함수
public void speedUp(){
        if (this.velocity >=120){
            this.velocity = 120;
        }else {
            this.velocity++;
        }

}
//    속도 올리는 함수
    public void speedDown(){
        if (this.velocity <= 0){
            this.velocity = 0;
        }else {
            this.velocity--;
        }

    }


//    현재 속도가 얼마인지 알려주는 함수
    public int showSpeed(){
        return this.velocity;
    }

}
