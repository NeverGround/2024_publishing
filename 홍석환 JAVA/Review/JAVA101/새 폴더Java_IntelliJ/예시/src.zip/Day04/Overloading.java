package Day04;

public class Overloading {
    public static void main(String[] args) {
        Calculator ca = new Calculator();

        System.out.println(ca.add(1,2));
    }
}

//클래스에서 두 함수 이름이 중복되는 것: 오버로딩
//조건 1. 함수 이름이 같아야함
//조건 2. 매개변수의 타입, 개수, 순서가 달라야 함

class Calculator {
    int num;

    public int add(int a, int b){
        return a+b;
    }

    public double add(double a, double b){
        return a + b;
    }
}