package Day04;

public class DieselEngine implements Engine1{

    @Override
    public void start() {
        System.out.println("디젤 엔진 부릉");
    }
}
