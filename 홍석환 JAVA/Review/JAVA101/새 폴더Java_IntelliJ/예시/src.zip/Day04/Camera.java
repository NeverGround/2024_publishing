package Day04;

//인터페이스 안에는 보통 함수를 씀

public interface Camera {
    void takePhoto();


}
