package Day04;

public class ElecEngine implements Engine1{

    @Override
    public void start() {
        System.out.println("전기 부릉");
    }
}
