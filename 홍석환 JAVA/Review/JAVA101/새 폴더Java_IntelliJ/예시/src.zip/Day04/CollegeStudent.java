package Day04;

public class CollegeStudent extends Student{

    private String course;


    public void setCourse(String course){
        this.course = course;
    }
}
