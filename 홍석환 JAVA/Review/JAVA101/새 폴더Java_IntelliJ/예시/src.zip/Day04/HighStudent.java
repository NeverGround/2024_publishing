package Day04;

public class HighStudent extends Student{

    @Override
    public String study() {

        return "고등학생이 수능공부를 준비합니다";
    }


}
