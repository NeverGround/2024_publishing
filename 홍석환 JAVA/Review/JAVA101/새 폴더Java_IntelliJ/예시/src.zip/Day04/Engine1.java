package Day04;

public interface Engine1 {
    void start();
}
