package Day04;

public class Engine {
    public void  start(){
        System.out.println("엔진 부르릉");
    }
}
