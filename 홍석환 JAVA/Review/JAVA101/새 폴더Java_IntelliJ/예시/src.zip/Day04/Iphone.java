package Day04;



public class Iphone implements Camera, FaceID, Siri {
    @Override
    public void takePhoto() {
        System.out.println("찰칵");
    }

    @Override
    public void FaceCheck() {
        System.out.println("띠리링");
    }

    @Override
    public void Talk() {
        System.out.println("무엇을 도와드릴까요?");
    }
}


