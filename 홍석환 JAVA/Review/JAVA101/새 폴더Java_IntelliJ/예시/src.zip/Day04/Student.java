package Day04;

public class Student {
    private String name;
    private int grade;

    protected  String school;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getGrade() {
        return grade;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }

    public String study (){
        return this.name + "학생이 공부합니다.";
    }

    public String exam (){
        return this.name + "학생이 시험봅니다.";
    }

    public String getStudentInfo (String name, int grade){
        this.name = name;
        this.grade = grade;
        return "학생이름 :" + name  + " 학생 학년 " + grade ;
    }


}
