package Day04;


// 직접적인 관계 <-> 간접적인 관계
//(A <-> B) <-> (A - I - B)
public class Car {
    private Engine engine;

    public Car(Engine engine) {
        this.engine = engine;
    }

    public void start(){
        this.engine.start();
    }
}
