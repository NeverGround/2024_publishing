package Day04;

public interface FaceID {
    void FaceCheck();
}
