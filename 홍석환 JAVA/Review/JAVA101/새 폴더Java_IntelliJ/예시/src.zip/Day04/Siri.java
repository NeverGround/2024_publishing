package Day04;

public interface Siri {
    void Talk();

}
