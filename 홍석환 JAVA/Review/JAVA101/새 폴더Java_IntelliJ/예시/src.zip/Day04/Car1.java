package Day04;

public class Car1 {
    private  Engine1 engine1;

    public  Car1(Engine1 engine1){
        this.engine1 = engine1;
    }

    public  void start(){
        this.engine1.start();
    }
}
