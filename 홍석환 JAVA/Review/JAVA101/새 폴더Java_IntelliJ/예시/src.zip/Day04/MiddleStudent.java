package Day04;

//중학생 클래스
//이름, 학년
//공부하기, 시험보기, 학생정보 얻기

//대학생 클래스
//이름, 학년, 수강과목
//공부하기, 시험보기, 학생정보 얻기, 수강과목 추가하기

public class MiddleStudent extends Student {


}
