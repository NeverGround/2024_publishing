package Day05;

public class Ob {
    // 상속: Object -> student -> middle or college
    // Object 주요 메소드
    // toString();
    // equals(Object obj);

}
