package Day05;

// type NAME = "엄준식" | "최호석" | "김자바"
// interface: imple || [상수 -> enum]

public class Test {
    public static void main(String[] args) {
        Days one_day = Days.MONDAY;
        System.out.println(MESSAGE.OK);
        System.out.println(MESSAGE.NOT_FOUND);

    }
}
