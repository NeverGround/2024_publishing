package Day05

object TEST_API {
    const val FRUIT = "faker.api:"
}