package Day05;

public interface DaysInterface {
    String MONDAY = "월요일";
    String TUESDAY = "화요일";
    String WENSDAY = "수요일";
}
