package Day05

// Kotlin
// 1. 자바 100% 호환 가능
// 2. JS/TS 문법 비슷함
// 3. 자바의 코드의 1/2
object MESSAGE {
    const val OK = "성공"
    const val NOT_FOUND = "없음"
    const val SERVER_ERROR = "서버에러"
}