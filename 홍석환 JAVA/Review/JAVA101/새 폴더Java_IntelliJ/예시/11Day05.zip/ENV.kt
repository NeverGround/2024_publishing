package Day05

object ENV {
    const val LOCALHOST = "localhost:3000"
    const val REAL_SERVER = "www."
}