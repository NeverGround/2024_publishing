package Day05;

public class Wrapper {
    //[int, double, char, byte, boolean, long]
    //객체타입(Wrapper)
    //객체 지향성을 위해서
    Integer a = 1;
    //deprecated[쓰지마세요]
    Integer a1 = Integer.parseInt("123"); // 123
    Double b = 3.14;
    Character c = 'x';
    Boolean d = true;
}
