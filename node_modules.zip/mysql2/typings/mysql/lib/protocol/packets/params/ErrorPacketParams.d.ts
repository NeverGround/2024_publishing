declare interface ErrorPacketParams {
  message?: string;
  code?: number | string;
}

export { ErrorPacketParams };
