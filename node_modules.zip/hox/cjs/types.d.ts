export declare type DepsFn<T> = (model: T) => unknown[];
