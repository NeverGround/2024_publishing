import { DepsFn } from './types';
export declare function createGlobalStore<T>(hook: () => T): readonly [(depsFn?: DepsFn<T> | undefined) => T, () => T | undefined];
