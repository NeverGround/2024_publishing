import { Container } from './container';
import { DepsFn } from './types';
export declare function useDataFromContainer<T, P>(container: Container<T, P>, depsFn?: DepsFn<T>): T;
