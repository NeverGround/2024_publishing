import { ComponentType, NamedExoticComponent } from 'react';
import { NonReactStatics } from 'hoist-non-react-statics';
import { DepsFn } from './types';
export declare type Omit<T, K extends keyof T> = Pick<T, Exclude<keyof T, K>>;
export declare type GetProps<C> = C extends ComponentType<infer P> ? P : never;
export declare type ConnectedComponent<C extends ComponentType<any>, P> = NamedExoticComponent<JSX.LibraryManagedAttributes<C, P>> & NonReactStatics<C> & {
    WrappedComponent: C;
};
export declare type Matching<InjectedProps, DecorationTargetProps> = {
    [P in keyof DecorationTargetProps]: P extends keyof InjectedProps ? InjectedProps[P] extends DecorationTargetProps[P] ? DecorationTargetProps[P] : InjectedProps[P] : DecorationTargetProps[P];
};
export declare type Shared<InjectedProps, DecorationTargetProps> = {
    [P in Extract<keyof InjectedProps, keyof DecorationTargetProps>]?: InjectedProps[P] extends DecorationTargetProps[P] ? DecorationTargetProps[P] : never;
};
export declare type InferableComponentEnhancerWithProps<TInjectedProps, TNeedsProps> = <C extends ComponentType<Matching<TInjectedProps, GetProps<C>>>>(component: C) => ConnectedComponent<C, Omit<GetProps<C>, keyof Shared<TInjectedProps, GetProps<C>>> & TNeedsProps>;
declare type MapStoreToProps<TStoreProps, TOwnProps, Store> = (store: Store, ownProps: TOwnProps) => TStoreProps;
declare type UseStore<T> = (depsFn?: DepsFn<T>) => T;
export declare function withStore<TStoreProps, TOwnProps, T>(useStore: UseStore<T>, mapStoreToProps: MapStoreToProps<TStoreProps, TOwnProps, T>): InferableComponentEnhancerWithProps<TStoreProps, TOwnProps>;
export declare function withStore<TStoreProps, TOwnProps, Store>(useStores: UseStore<any>[], mapStoreToProps: MapStoreToProps<TStoreProps, TOwnProps, any[]>): InferableComponentEnhancerWithProps<TStoreProps, TOwnProps>;
export {};
