import { ComponentType, FC, PropsWithChildren } from 'react';
export declare function registerGlobalExecutor(executor: ComponentType): void;
export declare const HoxRoot: FC<PropsWithChildren<{}>>;
