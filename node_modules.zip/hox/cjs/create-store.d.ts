import React from 'react';
import { DepsFn } from './types';
export declare type CreateStoreOptions = {
    memo?: boolean;
};
export declare function createStore<T, P = {}>(hook: (props: P) => T, options?: CreateStoreOptions): readonly [(depsFn?: DepsFn<T> | undefined) => T, React.NamedExoticComponent<React.PropsWithChildren<P>> | React.FC<React.PropsWithChildren<P>>];
