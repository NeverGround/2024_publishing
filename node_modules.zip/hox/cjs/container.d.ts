declare type Subscriber<T> = (data: T) => void;
export declare class Container<T = unknown, P = {}> {
    hook: (props: P) => T;
    constructor(hook: (props: P) => T);
    subscribers: Set<Subscriber<T>>;
    data: T;
    notify(): void;
}
export {};
