export default 'fox'
