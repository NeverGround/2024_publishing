export const MESSAGE = {
  ID: "사용하시는 이메일을 입력해 주세요 (abc@xxxx.com)",
  PW: "특수문자, 숫자, 영문 3가지 조합으로 8자 이상 15이하로 입력해 주세요",
  PWCHECK: "동일한 비밀번호를 입력해 주세요.",
};
